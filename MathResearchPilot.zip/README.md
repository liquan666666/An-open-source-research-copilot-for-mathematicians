# MathResearchPilot

An open-source research copilot for mathematicians.

**Features**
- Adaptive topic & paper recommendation (MSC-first, keyword fallback)
- arXiv OA paper search & download
- Focus papers with custom page ranges
- Hybrid theory/compute research roadmap
- Daily executable tasks with supervision
- Automatic + manual theory/compute ratio control
- Fully explainable task → paper → page → source chain

## Quick Start (Docker)
```bash
docker compose up --build
```
- Web UI: http://localhost:3000
- API Docs: http://localhost:8000/docs
```
