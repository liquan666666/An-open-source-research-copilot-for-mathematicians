export default function Home(){
  return <h1>MathResearchPilot Web UI</h1>
}
